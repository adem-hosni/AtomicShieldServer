fx_version 'cerulean'
games { 'gta5' }

author 'Atomic Shiled'
description 'Atomic Shield - Advanced External Anticheat for FiveM'
version '1.0.0'

server_script 'AtomicShield/bin/Release/AtomicShield.net.dll'

repository 'https://atomic-shield.com'
