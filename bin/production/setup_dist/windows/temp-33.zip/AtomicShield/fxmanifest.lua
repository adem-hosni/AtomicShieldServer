fx_version 'cerulean'
games { 'gta5' }

author 'Atomic Shield'
description 'Atomic Shield - Advanced External AntiCheat for FiveM'
version '1.0.0'

server_script 'src/main.js'

repository 'https://atomic-shield.com'
